# GodMace — implementation notes (MC 26.2 / Paper 26.2)

Facts discovered during research, kept here so future changes don't re-learn them the hard way.

## Versioning & formats

- MC switched to year-based versions in 2026: 26.1 "Tiny Takeover", 26.2 "Chaos Cubed" (current stable).
- Pack formats moved from `pack_format` to `min_format`/`max_format` in 25w31a.
- Exact 26.2 values (from misode/mcmeta version.json history): **data pack 107.1**, **resource pack 88**.
- Paper versioning changed too: API artifacts are now `io.papermc.paper:paper-api:26.2.build.<N>-stable` (e.g. `26.2.build.112-stable`), NOT `-R0.1-SNAPSHOT`. Old v2 download API is sunset; use `fill.papermc.io/v3`.

## Data component syntax (verified against minecraft.wiki, 26.2)

- `attribute_modifiers` is a **direct list** (no `modifiers:` wrapper):
  `[{id:"ns:key",type:"minecraft:attack_damage",slot:"mainhand",operation:"add_value",amount:5.0}, ...]`
- Operations: `add_value`, `add_multiplied_base`, `add_multiplied_total`.
- `enchantments` is a **flat map**: `{"minecraft:density":4,"minecraft:vanishing_curse":1}` (no `levels:` wrapper since 1.21.5).
- Text components are SNBT objects since 1.21.5: `custom_name={text:"Iron Mace",color:"#E6E6E6",italic:false}` — not quoted JSON strings.
- `unbreakable={}` (empty compound).
- Player base attack damage attribute = 1.0, so modifier amount = desired total − 1. Vanilla mace speed modifier = −3.4 (→ 0.6/s).
- Density: +0.5 smash damage per level per block fallen. Wind Burst: ~8 blocks launch per level.

## World layout gotcha (26.1+)

Dimension folders moved to `<level>/dimensions/<namespace>/<dimension>`, but data packs are still read from `<level>/datapacks/`. `World#getWorldFolder()` returns the *dimension* folder — writing datapacks there silently fails to load. `GodMacePlugin.resolveLevelRoot()` walks up to the `dimensions` parent to find the true level root.

A datapack copied while the server runs loads on next boot (or `/reload`), not instantly.

## Paper API notes

- ITEM registry is frozen: plugins cannot register new item IDs (`RegistryEvents` has no ITEM). Custom items on Paper = vanilla item + components + resource pack.
- `DataComponentTypes.UNBREAKABLE` is non-valued: single-arg `stack.setData(DataComponentTypes.UNBREAKABLE)`.
- `ItemEnchantments.itemEnchantments()` returns a fluent `ItemEnchantments.Builder`.
- Attribute modifiers take `org.bukkit.NamespacedKey`; `ITEM_MODEL` takes Adventure `Key`.
- Build environment quirk: Arch system `gradle` package is broken ("Cannot find module gradle-public-api-legacy"); use the wrapper distribution under `~/.gradle/wrapper/dists/gradle-9.6.1-bin/.../bin/gradle`. Only JDK 26 installed — no toolchain pinning, just `options.release = 25`.

## Smoke test evidence (2026-08-20)

Paper 26.2 build 112 booted headless with the plugin:
- Plugin loads/enables/disables cleanly, zero errors.
- Boot 1 writes datapack to `<world>/datapacks/GodMace`; boot 2 logs `Found new data pack file/GodMace, loading it automatically` and `datapack list` shows `file/GodMace (world)` enabled.
