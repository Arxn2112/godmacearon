package dev.godmace;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.stream.Stream;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * GodMace entry point.
 *
 * <p>Phase 1 ships items only: the plugin bundles the GodMace datapack
 * (one {@code /function godmace:<tier>} give-function per mace) and installs
 * it into the default world's datapacks folder on enable. No gameplay
 * listeners yet — kill-to-unlock progression arrives in phase 2.</p>
 */
public final class GodMacePlugin extends JavaPlugin {

    private static final String DATAPACK_RESOURCE_ROOT = "datapack";
    private static final String DATAPACK_FOLDER_NAME = "GodMace";

    @Override
    public void onEnable() {
        try {
            boolean installed = installBundledDatapack();
            if (installed) {
                getLogger().info("Installed bundled datapack into the default world. "
                        + "If this is a fresh copy over an existing install, run /reload "
                        + "or restart for it to load.");
            } else {
                getLogger().info("Datapack already present; left untouched.");
            }
        } catch (IOException | URISyntaxException e) {
            getLogger().severe("Failed to install bundled datapack: " + e.getMessage());
            getSLF4JLogger().error("Datapack installation failed", e);
        }
    }

    /**
     * Copies {@code datapack/} from the plugin jar (or source tree when run
     * in an IDE) into {@code <level root>/datapacks/GodMace/}.
     *
     * @return true if files were copied, false if the datapack already existed
     */
    private boolean installBundledDatapack() throws IOException, URISyntaxException {
        World defaultWorld = getServer().getWorlds().getFirst();
        Path target = resolveLevelRoot(defaultWorld)
                .resolve("datapacks")
                .resolve(DATAPACK_FOLDER_NAME);

        if (Files.exists(target)) {
            return false;
        }

        Files.createDirectories(target);
        copyDatapackResources(target);
        getLogger().info("Datapack written to " + target);
        return true;
    }

    /**
     * Resolves the level root folder that holds {@code datapacks/}.
     *
     * <p>Since 26.1 a world's dimension folders live under
     * {@code <level>/dimensions/<namespace>/<dimension>}, while data packs are
     * still read from {@code <level>/datapacks/}. On older layouts the world
     * folder itself is the level root.</p>
     */
    private Path resolveLevelRoot(World world) {
        Path folder = world.getWorldFolder().toPath().toAbsolutePath().normalize();
        Path cursor = folder;
        while ((cursor = cursor.getParent()) != null) {
            if ("dimensions".equals(cursor.getFileName() == null ? "" : cursor.getFileName().toString())) {
                Path root = cursor.getParent();
                if (root != null) {
                    return root;
                }
            }
        }
        return folder;
    }

    private void copyDatapackResources(Path target) throws IOException, URISyntaxException {
        URI root = getClass().getProtectionDomain().getCodeSource().getLocation().toURI();
        Path self = Path.of(root);

        if (Files.isDirectory(self)) {
            // Running from an exploded build (IDE / gradle run): plain file walk.
            Path source = self.resolve(DATAPACK_RESOURCE_ROOT);
            if (!Files.isDirectory(source)) {
                throw new IOException("Missing " + source + " — run 'gradle build' first");
            }
            try (Stream<Path> paths = Files.walk(source)) {
                for (Path file : paths.filter(Files::isRegularFile).toList()) {
                    Path relative = source.relativize(file);
                    Path destination = target.resolve(relative);
                    Files.createDirectories(destination.getParent());
                    Files.copy(file, destination, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            return;
        }

        // Running from inside the plugin jar.
        try (FileSystem jar = FileSystems.newFileSystem(self, (ClassLoader) null)) {
            Path source = jar.getPath(DATAPACK_RESOURCE_ROOT);
            if (!Files.isDirectory(source)) {
                throw new IOException("Jar is missing the bundled " + DATAPACK_RESOURCE_ROOT + "/ folder");
            }
            try (Stream<Path> paths = Files.walk(source)) {
                for (Path file : paths.filter(Files::isRegularFile).sorted(Comparator.naturalOrder()).toList()) {
                    Path relative = source.relativize(file);
                    Path destination = target.resolve(relative.toString());
                    Files.createDirectories(destination.getParent());
                    copy(file, destination);
                }
            }
        }
    }

    private static void copy(Path from, Path to) throws IOException {
        try (InputStream in = Files.newInputStream(from)) {
            Files.copy(in, to, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
