package dev.godmace;

import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.ItemAttributeModifiers;
import io.papermc.paper.datacomponent.item.ItemEnchantments;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;

/**
 * Builds the eight mace ItemStacks.
 *
 * <p>Every tier is a real {@link Material#MACE} customized via data
 * components: custom name, item model (texture), attack damage/speed
 * attribute modifiers, baked enchantments, unbreakable, and the vanishing
 * curse. The produced stacks match the datapack give-functions exactly.</p>
 */
public final class MaceItems {

    private MaceItems() {
    }

    /** Creates a fresh stack for the given tier. */
    public static ItemStack create(MaceTier tier) {
        ItemStack stack = ItemStack.of(Material.MACE);

        stack.setData(DataComponentTypes.ITEM_NAME, Component.text(tier.displayName())
                .color(tier.color())
                .decoration(TextDecoration.ITALIC, false));

        stack.setData(DataComponentTypes.ITEM_MODEL, Key.key("godmace", tier.id()));

        stack.setData(DataComponentTypes.UNBREAKABLE);

        ItemAttributeModifiers modifiers = ItemAttributeModifiers.itemAttributes()
                .addModifier(Attribute.ATTACK_DAMAGE,
                        new AttributeModifier(
                                new org.bukkit.NamespacedKey("godmace", tier.id() + "_damage"),
                                tier.damageModifier(),
                                AttributeModifier.Operation.ADD_NUMBER),
                        EquipmentSlotGroup.MAINHAND)
                .addModifier(Attribute.ATTACK_SPEED,
                        new AttributeModifier(
                                new org.bukkit.NamespacedKey("godmace", tier.id() + "_speed"),
                                MaceTier.ATTACK_SPEED_MODIFIER,
                                AttributeModifier.Operation.ADD_NUMBER),
                        EquipmentSlotGroup.MAINHAND)
                .build();
        stack.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, modifiers);

        ItemEnchantments.Builder enchantments = ItemEnchantments.itemEnchantments()
                .add(Enchantment.VANISHING_CURSE, 1);
        if (tier.density() > 0) {
            enchantments.add(Enchantment.DENSITY, tier.density());
        }
        if (tier.windBurst() > 0) {
            enchantments.add(Enchantment.WIND_BURST, tier.windBurst());
        }
        stack.setData(DataComponentTypes.ENCHANTMENTS, enchantments.build());

        return stack;
    }
}
