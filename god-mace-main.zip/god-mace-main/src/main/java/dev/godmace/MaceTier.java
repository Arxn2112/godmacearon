package dev.godmace;

import net.kyori.adventure.text.format.TextColor;

/**
 * The eight mace tiers, weakest to strongest.
 *
 * <p>Damage values are the total attack damage shown in-game (player base
 * attribute of 1.0 plus the modifier applied by the item). Density levels add
 * +0.5 smash damage per level per block fallen; Wind Burst launches the
 * attacker ~8 blocks per level after a smash hit.</p>
 */
public enum MaceTier {
    WOOD_MACE("wood_mace", "Wood Mace", TextColor.color(0x9A6B39), 3.0, 0, 0),
    STONE_MACE("stone_mace", "Stone Mace", TextColor.color(0xA8A8A8), 4.0, 1, 0),
    COPPER_MACE("copper_mace", "Copper Mace", TextColor.color(0xE77C56), 5.0, 2, 1),
    GOLD_MACE("gold_mace", "Gold Mace", TextColor.color(0xFCBE2E), 5.5, 3, 1),
    IRON_MACE("iron_mace", "Iron Mace", TextColor.color(0xE6E6E6), 6.0, 4, 2),
    DIAMOND_MACE("diamond_mace", "Diamond Mace", TextColor.color(0x33EBCB), 7.0, 5, 2),
    NETHERITE_MACE("netherite_mace", "Netherite Mace", TextColor.color(0xB04A4A), 8.0, 6, 3),
    GOD_MACE("god_mace", "God Mace", TextColor.color(0xC58AFF), 12.0, 7, 3);

    /** Attack speed modifier shared by every tier (vanilla mace speed, 0.6/s). */
    public static final double ATTACK_SPEED_MODIFIER = -3.4;

    private final String id;
    private final String displayName;
    private final TextColor color;
    private final double totalDamage;
    private final int density;
    private final int windBurst;

    MaceTier(String id, String displayName, TextColor color,
             double totalDamage, int density, int windBurst) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.totalDamage = totalDamage;
        this.density = density;
        this.windBurst = windBurst;
    }

    /** Item model / texture id under the {@code godmace} namespace, e.g. {@code wood_mace}. */
    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public TextColor color() {
        return color;
    }

    /** Total attack damage the mace deals on a normal hit. */
    public double totalDamage() {
        return totalDamage;
    }

    /** Modifier amount to reach {@link #totalDamage()} from the player base of 1.0. */
    public double damageModifier() {
        return totalDamage - 1.0;
    }

    /** Baked Density enchantment level (0 = none). */
    public int density() {
        return density;
    }

    /** Baked Wind Burst enchantment level (0 = none). */
    public int windBurst() {
        return windBurst;
    }
}
