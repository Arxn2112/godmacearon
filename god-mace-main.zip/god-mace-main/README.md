# GodMace

Paper **26.2** server-side plugin providing eight tiered maces for the GodMace SMP video — wood to god.

Every mace is a real `minecraft:mace` customized with data components (custom name, texture via `item_model`, attack damage/speed modifiers, baked enchantments, unbreakable, Curse of Vanishing). Vanilla smash mechanics work out of the box on all tiers.

## Tier table

| Mace | Damage | Density | Wind Burst |
|---|---|---|---|
| Wood Mace | 3 | — | — |
| Stone Mace | 4 | I | — |
| Copper Mace | 5 | II | I |
| Gold Mace | 5.5 | III | I |
| Iron Mace | 6 | IV | II |
| Diamond Mace | 7 | V | II |
| Netherite Mace | 8 | VI | III |
| God Mace | 12 | VII | III |

All tiers: attack speed 0.6/s (vanilla mace), unbreakable, Curse of Vanishing I.

## Install

1. Drop `build/libs/GodMace-0.1.0.jar` into the server's `plugins/` folder.
2. Start the server twice (first start copies the bundled datapack into `<world>/datapacks/GodMace`, second start loads it). Alternatively run `/reload` after the first start.
3. Host the resource pack so players see custom textures:
   - Run `./gradlew resourcePack` — prints the SHA-1 and creates `build/libs/godmace-resourcepack-v0.1.0.zip`.
   - Upload the zip anywhere reachable (web server, GitHub release) and set in `server.properties`:
     ```properties
     resource-pack=https://your-host/godmace-resourcepack-v0.1.0.zip
     resource-pack-sha1=<printed sha1>
     require-resource-pack=true
     ```

## Getting maces in-game

Datapack functions (short, script-friendly):

```
/function godmace:wood_mace
/function godmace:stone_mace
/function godmace:copper_mace
/function godmace:gold_mace
/function godmace:iron_mace
/function godmace:diamond_mace
/function godmace:netherite_mace
/function godmace:god_mace
```

Give one to another player (from console or with OP):

```
/execute as <player> run function godmace:god_mace
```

Or raw vanilla `/give` with inline components (iron example):

```
/give @s minecraft:mace[custom_name={text:"Iron Mace",color:"#E6E6E6",italic:false},item_model="godmace:iron_mace",unbreakable={},enchantments={"minecraft:density":4,"minecraft:wind_burst":2,"minecraft:vanishing_curse":1},attribute_modifiers=[{id:"godmace:iron_mace_damage",type:"minecraft:attack_damage",slot:"mainhand",operation:"add_value",amount:5.0},{id:"godmace:iron_mace_speed",type:"minecraft:attack_speed",slot:"mainhand",operation:"add_value",amount:-3.4}]] 1
```

> Note: Paper cannot register new item IDs, so `godmace:*` exists as the *texture/model* namespace (`item_model`), while the item itself remains `minecraft:mace`. This is the only supported way to get custom items on Paper with vanilla clients.

## Textures

All eight tiers have textures in `images/` (`wood`, `stone`, `copper`, `god` are hand-drawn; `gold`, `iron`, `diamond`, `netherite` started as generated placeholder tints and live alongside them). To replace any texture, drop a finished 16×16 PNG named `<tier>_mace.png` into `images/` and run `gradle resourcePack` again. The generator script (`scripts/gen_placeholder_icons.py`) skips tiers that already have finished art, so re-running it never overwrites your work.

## Building

```
./gradlew build          # plugin jar -> build/libs/GodMace-0.1.0.jar
./gradlew resourcePack   # resource pack zip + SHA-1 -> build/libs/
```

Requires JDK 25+ (compiles targeting release 25). The Gradle wrapper downloads Gradle 9.6.1 automatically on first run.

## Roadmap (phase 2)

Kill-to-unlock progression: player kills (players only) while holding their current mace advance them to the next tier (one kill per tier); death resets to the Wood Mace. Admin/script commands for retakes will be included. Not implemented yet.
