#!/usr/bin/env python3
"""Generate placeholder mace icons for tiers without finished art.

Tints the stone mace silhouette toward each material's palette so the
placeholders read as distinct metals until real textures replace them.
Tiers that already have a PNG in images/ are skipped, so re-running after
adding finished art never overwrites or shadows it.

Usage: python3 scripts/gen_placeholder_icons.py
Output: images/generated/<tier>_mace.png
"""

from pathlib import Path

from PIL import Image, ImageOps

REPO = Path(__file__).resolve().parent.parent
SOURCE = REPO / "images" / "stone_mace.png"
FINISHED_DIR = REPO / "images"
OUT_DIR = REPO / "images" / "generated"

# tier -> (shadow/black point, highlight/white point, mid tone)
PALETTES = {
    "gold": ((61, 38, 8), (255, 236, 160), (250, 190, 40)),
    "iron": ((38, 38, 44), (245, 245, 250), (198, 198, 205)),
    "diamond": ((8, 64, 66), (185, 255, 250), (85, 225, 215)),
    "netherite": ((16, 11, 13), (132, 108, 112), (72, 58, 62)),
}


def main() -> None:
    base = Image.open(SOURCE).convert("RGBA")
    alpha = base.getchannel("A")
    gray = ImageOps.grayscale(base)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    generated = 0
    for tier, (black, white, mid) in PALETTES.items():
        if (FINISHED_DIR / f"{tier}_mace.png").exists():
            print(f"skip {tier}: finished art exists in images/")
            continue
        tinted = ImageOps.colorize(gray, black=black, white=white, mid=mid)
        tinted.putalpha(alpha)
        out = OUT_DIR / f"{tier}_mace.png"
        tinted.save(out)
        print(f"wrote {out.relative_to(REPO)}")
        generated += 1

    if generated == 0:
        print("nothing to generate — all tiers have finished art")


if __name__ == "__main__":
    main()
