import java.security.MessageDigest

plugins {
    java
}

group = "dev.godmace"
version = "0.1.0"
description = "Eight tiered maces for the GodMace SMP, from wood to god."

java {
    // Compile with the local JDK (26) targeting release 25, which is what
    // Paper 26.2 requires at runtime.
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.2.build.112-stable")
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release = 25
}

tasks.processResources {
    filesMatching("plugin.yml") {
        expand("version" to project.version)
    }
}

// ---------------------------------------------------------------------------
// Resource pack assembly: staged copy of src/main/resources/resourcepack plus
// textures synced from images/ (finished art) and images/generated/ (placeholders).
// ---------------------------------------------------------------------------

val resourcePackStaging = layout.buildDirectory.dir("resourcepack-staged")

tasks.register<Copy>("syncTextures") {
    from("images") {
        include("*_mace.png")
    }
    from("images/generated") {
        include("*_mace.png")
    }
    into(resourcePackStaging.map { it.dir("assets/godmace/textures/item") })
}

tasks.register<Copy>("stageResourcePack") {
    dependsOn(tasks.named("syncTextures"))
    from("src/main/resources/resourcepack")
    into(resourcePackStaging)
}

tasks.register<Zip>("resourcePack") {
    dependsOn(tasks.named("stageResourcePack"))
    archiveFileName = "godmace-resourcepack-v${project.version}.zip"
    destinationDirectory = layout.buildDirectory.dir("libs")
    from(resourcePackStaging)

    doLast {
        val digest = MessageDigest.getInstance("SHA-1")
        archiveFile.get().asFile.inputStream().use { stream ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = stream.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        val sha1 = digest.digest().joinToString("") { byte -> "%02x".format(byte) }
        logger.lifecycle("Resource pack SHA-1: {}", sha1)
        logger.lifecycle("server.properties:")
        logger.lifecycle("  resource-pack=${archiveFile.get().asFile.absolutePath}")
        logger.lifecycle("  resource-pack-sha1={}", sha1)
    }
}

tasks.assemble {
    dependsOn(tasks.named("resourcePack"))
}
